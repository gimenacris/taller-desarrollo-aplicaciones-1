/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class Carnet {

    private String codigo;
    private String dni;
    private String nombreCompleto;
    private String facultad;
    private String carrera;

    public Carnet(String codigo, String dni) {
        this.codigo = codigo;
        this.dni = dni;
    }

    public Carnet(String codigo, String dni, String nombreCompleto, String facultad, String carrera) {
        this.codigo = codigo;
        this.dni = dni;
        this.nombreCompleto = nombreCompleto;
        this.facultad = facultad;
        this.carrera = carrera;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getDni() {
        return dni;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public String getFacultad() {
        return facultad;
    }

    public String getCarrera() {
        return carrera;
    }

    public void actualizarDatos(String nombreCompleto, String facultad, String carrera) {
        this.nombreCompleto = nombreCompleto;
        this.facultad = facultad;
        this.carrera = carrera;
    }
}
