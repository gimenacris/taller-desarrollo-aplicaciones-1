/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Carnet;
import vista.CMenu;
import vista.CCarnet;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class MenuControlador implements ActionListener, MouseListener, KeyListener {

    private final CMenu vista;
    public static Carnet carnetSeleccionado = null;

    public MenuControlador(CMenu vista) {
        this.vista = vista;

        this.vista.btnCrear.addActionListener(this);
        this.vista.btnActualizar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
        this.vista.btnSalir.addActionListener(this);

        this.vista.tblDatos.addMouseListener(this);
        this.vista.txtBuscar.addKeyListener(this);

        this.vista.btnActualizar.setEnabled(false);
        this.vista.btnEliminar.setEnabled(false);

        // Cargar los datos de la base al iniciar
        cargarCarnetsDesdeBD();
    }

    private void cargarCarnetsDesdeBD() {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Código");
        modelo.addColumn("DNI");
        modelo.addColumn("Nombre Completo");
        modelo.addColumn("Facultad");
        modelo.addColumn("Carrera");

        try (Connection con = conexion.conectar()) {
            String sql = "SELECT * FROM carnets";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                modelo.addRow(new Object[]{
                    rs.getString("codigo"),
                    rs.getString("dni"),
                    rs.getString("nombre_completo"),
                    rs.getString("facultad"),
                    rs.getString("carrera")
                });
            }

            vista.tblDatos.setModel(modelo);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Error al cargar datos: " + e.getMessage());
        }
    }

    private void buscarCarnet() {
        String texto = vista.txtBuscar.getText().toLowerCase();

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Código");
        modelo.addColumn("DNI");
        modelo.addColumn("Nombre Completo");
        modelo.addColumn("Facultad");
        modelo.addColumn("Carrera");

        try (Connection con = conexion.conectar()) {
            String sql = "SELECT * FROM carnets WHERE LOWER(dni) LIKE ? OR LOWER(codigo) LIKE ? OR LOWER(nombre_completo) LIKE ?";
            PreparedStatement ps = con.prepareStatement(sql);
            String searchTerm = "%" + texto + "%";
            ps.setString(1, searchTerm);
            ps.setString(2, searchTerm);
            ps.setString(3, searchTerm);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                modelo.addRow(new Object[]{
                    rs.getString("codigo"),
                    rs.getString("dni"),
                    rs.getString("nombre_completo"),
                    rs.getString("facultad"),
                    rs.getString("carrera")
                });
            }

            vista.tblDatos.setModel(modelo);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Error al buscar: " + e.getMessage());
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.btnCrear) {
            crear();
        } else if (source == vista.btnActualizar) {
            actualizar();
        } else if (source == vista.btnEliminar) {
            eliminar();
        } else if (source == vista.btnSalir) {
            salir();
        }
    }

    private void crear() {
        CCarnet dialogo = new CCarnet(vista, true, "crear");
        dialogo.setVisible(true);
        cargarCarnetsDesdeBD();
        limpiarSeleccion();
    }

    private void actualizar() {
        if (carnetSeleccionado != null) {
            CCarnet dialogo = new CCarnet(vista, true, "actualizar");
            dialogo.setVisible(true);
            cargarCarnetsDesdeBD();
            limpiarSeleccion();
        } else {
            JOptionPane.showMessageDialog(vista, "Seleccione un carnet primero.");
        }
    }

    private void eliminar() {
        if (carnetSeleccionado != null) {
            int confirm = JOptionPane.showConfirmDialog(vista, "¿Seguro de eliminar este carnet?", "Confirmar", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                try (Connection con = conexion.conectar()) {
                    String sql = "DELETE FROM carnets WHERE codigo = ?";
                    PreparedStatement ps = con.prepareStatement(sql);
                    ps.setString(1, carnetSeleccionado.getCodigo());
                    ps.executeUpdate();
                    cargarCarnetsDesdeBD();
                    carnetSeleccionado = null;
                    limpiarSeleccion();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(vista, "Error al eliminar: " + e.getMessage());
                }
            }
        } else {
            JOptionPane.showMessageDialog(vista, "Seleccione un carnet primero.");
        }
    }

    private void salir() {
        int respuesta = JOptionPane.showOptionDialog(vista, "¿Estás seguro de salir?", "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, new Object[]{"Sí", "No"}, "No");
        if (respuesta == 0) {
            System.exit(0);
        }
        vista.txtBuscar.requestFocus();
    }

    private void limpiarSeleccion() {
        carnetSeleccionado = null;
        vista.btnActualizar.setEnabled(false);
        vista.btnEliminar.setEnabled(false);
        vista.tblDatos.clearSelection();
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        int fila = vista.tblDatos.getSelectedRow();
        if (fila >= 0) {
            String codigo = (String) vista.tblDatos.getValueAt(fila, 0); // columna 0 = código

            try (Connection con = conexion.conectar()) {
                String sql = "SELECT * FROM carnets WHERE codigo = ?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, codigo);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    carnetSeleccionado = new Carnet(
                        rs.getString("codigo"),
                        rs.getString("dni"),
                        rs.getString("nombre_completo"),
                        rs.getString("facultad"),
                        rs.getString("carrera")
                    );
                }
                vista.btnActualizar.setEnabled(true);
                vista.btnEliminar.setEnabled(true);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(vista, "Error al seleccionar: " + ex.getMessage());
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getSource() == vista.txtBuscar) {
            buscarCarnet();
        }
    }

    @Override public void mousePressed(MouseEvent e) {}
    @Override public void mouseReleased(MouseEvent e) {}
    @Override public void mouseEntered(MouseEvent e) {}
    @Override public void mouseExited(MouseEvent e) {}
    @Override public void keyTyped(KeyEvent e) {}
    @Override public void keyPressed(KeyEvent e) {}
}