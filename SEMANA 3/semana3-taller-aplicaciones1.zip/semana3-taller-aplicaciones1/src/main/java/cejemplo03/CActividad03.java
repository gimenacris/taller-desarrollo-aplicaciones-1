/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cejemplo03;

import java.util.ArrayList;
import vista.CLogin;
import vista.Usuario;

public class CActividad03 {

    public static ArrayList<Usuario> listaUsuarios = new ArrayList<>();

    public static Usuario buscarPorDni(String dni) {
        for (Usuario u : listaUsuarios) {
            if (u.getDni().equals(dni)) {
                return u;
            }
        }
        return null;
    }

    public static boolean agregarUsuario(Usuario nuevo) {
        if (buscarPorDni(nuevo.getDni()) == null) {
            listaUsuarios.add(nuevo);
            return true;
        }
        return false;
    }

    public static void main(String[] args) {
        Usuario admin = new Usuario("87654321", "Gimena", "Mendoza", "123", "admin");
        agregarUsuario(admin);
        
        CLogin objClogin = new CLogin();
        objClogin.setVisible(true);
    }
}
