/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

public class Cuadrado {

    private double lado;

    // Constructor vacío
    public Cuadrado() {
    }

    // Constructor con parámetro
    public Cuadrado(double lado) {
        this.lado = lado;
    }

    public double getLado() {
        return lado;
    }

    public void setLado(double lado) {
        this.lado = lado;
    }

    public double hallarArea() {
        double area = Math.pow(lado, 2);
        return area;
    }

    public double mostrarArea() {
        return hallarArea();
    }
}
