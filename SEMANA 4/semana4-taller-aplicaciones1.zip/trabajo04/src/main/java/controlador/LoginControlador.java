/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author USER 17
 */
import javax.swing.JOptionPane;
import java.util.ArrayList;
import modelo.ModeloUsuario;

public class LoginControlador {
    private ArrayList<ModeloUsuario> listaUsuarios;

    public LoginControlador() {
        listaUsuarios = new ArrayList<>();
        // Agregamos un usuario admin como ejemplo
        ModeloUsuario admin = new ModeloUsuario("75196752", "Gimena", "Mendoza", "123", "admin");
        agregarUsuario(admin);
    }

    public ModeloUsuario buscarPorDni(String dni) {
        for (ModeloUsuario u : listaUsuarios) {
            if (u.getDni().equals(dni)) { 
                return u;
            }
        }
        return null;
    }

    public boolean agregarUsuario(ModeloUsuario nuevo) {
        if (buscarPorDni(nuevo.getDni()) == null) {
            listaUsuarios.add(nuevo);
            return true;
        }
        return false;
    }

    public boolean verificarCredenciales(String dni, String contrasena) {
        ModeloUsuario usuario = buscarPorDni(dni);
        return usuario != null && usuario.getContrasena().equals(contrasena);
    }

    public ModeloUsuario obtenerUsuario(String dni) {
        return buscarPorDni(dni);
    }
}

