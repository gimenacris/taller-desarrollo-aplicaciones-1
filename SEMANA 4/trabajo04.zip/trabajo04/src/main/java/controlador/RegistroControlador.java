/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author USER 17
 */
import java.util.ArrayList;
import javax.swing.JOptionPane;
import modelo.ModeloUsuario;

public class RegistroControlador {
    private ArrayList<ModeloUsuario> listaUsuarios;

    public RegistroControlador(ArrayList<ModeloUsuario> listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
    }

    public boolean agregarUsuario(ModeloUsuario nuevo) {
        for (ModeloUsuario u : listaUsuarios) {
            if (u.getDni().equals(nuevo.getDni())) {
                return false; // Ya existe
            }
        }
        listaUsuarios.add(nuevo);
        return true;
    }
}

