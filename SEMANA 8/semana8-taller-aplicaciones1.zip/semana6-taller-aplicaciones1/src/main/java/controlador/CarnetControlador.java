/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Carnet;
import vista.CCarnet;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CarnetControlador implements ActionListener {

    private final CCarnet vista;
    private final String tipo;
    private boolean inicializando = true;

    public CarnetControlador(CCarnet vista, String tipo) {
        this.vista = vista;
        this.tipo = tipo;

        this.vista.btnCrear.addActionListener(this);
        this.vista.btnVolver.addActionListener(this);
        this.vista.cmbFacultad.addActionListener(e -> {
            if (!inicializando) {
                actualizarCarreras();
            }
        });

        cargarFacultades();

        if (tipo.equalsIgnoreCase("actualizar")) {
            cargarDatos();
        }

        inicializando = false;
    }

    private void cargarFacultades() {
        DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();
        try (Connection conn = conexion.conectar()) {
            String sql = "SELECT nombrefacultad FROM facultades";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                modelo.addElement(rs.getString("nombrefacultad"));
            }
            vista.cmbFacultad.setModel(modelo);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista, "Error al cargar facultades: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void actualizarCarreras() {
        String facultadSeleccionada = (String) vista.cmbFacultad.getSelectedItem();
        DefaultComboBoxModel<String> modeloCarreras = new DefaultComboBoxModel<>();

        if (facultadSeleccionada == null) {
            return;
        }

        try (Connection conn = conexion.conectar()) {
            String sqlFacultad = "SELECT codigofacultad FROM facultades WHERE nombrefacultad = ?";
            PreparedStatement psFacultad = conn.prepareStatement(sqlFacultad);
            psFacultad.setString(1, facultadSeleccionada);
            ResultSet rsFacultad = psFacultad.executeQuery();

            if (rsFacultad.next()) {
                String codFacultad = rsFacultad.getString("codigofacultad");

                String sqlCarreras = "SELECT nombrecarrera FROM carreras WHERE codigofacultad = ?";
                PreparedStatement psCarreras = conn.prepareStatement(sqlCarreras);
                psCarreras.setString(1, codFacultad);
                ResultSet rsCarreras = psCarreras.executeQuery();

                while (rsCarreras.next()) {
                    modeloCarreras.addElement(rsCarreras.getString("nombrecarrera"));
                }
            }

            vista.cmbCarrera.setModel(modeloCarreras);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista, "Error al actualizar carreras: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarDatos() {
        String codigo = MenuControlador.carnetSeleccionado.getCodigo();
        String dni = MenuControlador.carnetSeleccionado.getDni();

        String sql = "SELECT * FROM carnets WHERE codigo = ? AND dni = ?";

        try (Connection conn = conexion.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, codigo);
            stmt.setString(2, dni);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String nombre = rs.getString("nombre_completo");
                String codCarrera = rs.getString("codigocarrera");

                String nombreCarrera = obtenerNombreCarrera(conn, codCarrera);
                String nombreFacultad = obtenerNombreFacultadDesdeCarrera(conn, codCarrera);

                vista.txtCodigo.setText(codigo);
                vista.txtDni.setText(dni);
                vista.txtNombre.setText(nombre);
                vista.cmbFacultad.setSelectedItem(nombreFacultad);
                actualizarCarreras();
                vista.cmbCarrera.setSelectedItem(nombreCarrera);

                vista.txtCodigo.setEditable(false);
                vista.txtDni.setEditable(false);
            } else {
                JOptionPane.showMessageDialog(vista, "Carnet no encontrado.", "Aviso", JOptionPane.WARNING_MESSAGE);
                vista.dispose();
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista, "Error al cargar datos:\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String obtenerNombreCarrera(Connection con, String codCarrera) {
        String sql = "SELECT nombrecarrera FROM carreras WHERE codigocarrera = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, codCarrera);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("nombrecarrera");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista, "Error al obtener nombre de carrera:\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }

    private String obtenerNombreFacultadDesdeCarrera(Connection con, String codCarrera) {
        String codFacultad = null;
        String sqlCarrera = "SELECT codigofacultad FROM carreras WHERE codigocarrera = ?";
        try (PreparedStatement psCarrera = con.prepareStatement(sqlCarrera)) {
            psCarrera.setString(1, codCarrera);
            ResultSet rsCarrera = psCarrera.executeQuery();
            if (rsCarrera.next()) {
                codFacultad = rsCarrera.getString("codigofacultad");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista, "Error al obtener codigo de facultad:\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }

        if (codFacultad != null) {
            String sqlFacultad = "SELECT nombrefacultad FROM facultades WHERE codigofacultad = ?";
            try (PreparedStatement psFacultad = con.prepareStatement(sqlFacultad)) {
                psFacultad.setString(1, codFacultad);
                ResultSet rsFacultad = psFacultad.executeQuery();
                if (rsFacultad.next()) {
                    return rsFacultad.getString("nombrefacultad");
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(vista, "Error al obtener nombre de facultad:\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        return null;
    }

    private boolean validarCampos() {
        if (vista.txtCodigo.getText().trim().isEmpty()
                || vista.txtDni.getText().trim().isEmpty()
                || vista.txtNombre.getText().trim().isEmpty()
                || vista.cmbFacultad.getSelectedIndex() == -1
                || vista.cmbCarrera.getSelectedIndex() == -1) {
            JOptionPane.showMessageDialog(vista, "Todos los campos deben estar completos.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    private void crearCarnet() {
        String codigoCarrera = obtenerCodigoCarrera((String) vista.cmbCarrera.getSelectedItem());

        if (codigoCarrera == null) {
            JOptionPane.showMessageDialog(vista, "No se encontro el codigo de la carrera.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sql = "INSERT INTO carnets (codigo, dni, nombre_completo, codigocarrera) VALUES (?, ?, ?, ?)";

        try (Connection conn = conexion.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, vista.txtCodigo.getText());
            stmt.setString(2, vista.txtDni.getText());
            stmt.setString(3, vista.txtNombre.getText());
            stmt.setString(4, codigoCarrera);
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(vista, "Carnet creado exitosamente.");
            vista.dispose();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista, "Error al crear carnet:\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarCarnet() {
        String codigoCarrera = obtenerCodigoCarrera((String) vista.cmbCarrera.getSelectedItem());

        if (codigoCarrera == null) {
            JOptionPane.showMessageDialog(vista, "No se encontro el codigo de la carrera.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sql = "UPDATE carnets SET nombre_completo = ?, codigocarrera = ? WHERE codigo = ? AND dni = ?";

        try (Connection conn = conexion.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, vista.txtNombre.getText());
            stmt.setString(2, codigoCarrera);
            stmt.setString(3, vista.txtCodigo.getText());
            stmt.setString(4, vista.txtDni.getText());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(vista, "Carnet actualizado exitosamente.");
            vista.dispose();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista, "Error al actualizar carnet:\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String obtenerCodigoCarrera(String nombreCarrera) {
        String sql = "SELECT codigocarrera FROM carreras WHERE nombrecarrera = ?";
        try (Connection conn = conexion.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombreCarrera);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("codigocarrera");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(vista, "Error al obtener codigo de carrera:\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.btnVolver) {
            vista.dispose();
        } else if (source == vista.btnCrear) {
            if (validarCampos()) {
                if (tipo.equalsIgnoreCase("crear")) {
                    crearCarnet();
                } else if (tipo.equalsIgnoreCase("actualizar")) {
                    actualizarCarnet();
                }
            }
        }
    }
}
