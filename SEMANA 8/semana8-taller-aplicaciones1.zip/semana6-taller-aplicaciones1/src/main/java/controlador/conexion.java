/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author gimen
 */
public class conexion {
    private static final String URL = "jdbc:mysql://localhost:3306/gestion_carnets";
    private static final String USUARIO = "root"; // Cambia si es distinto
    private static final String CLAVE = "root123";       // Cambia si tienes contraseña

    public static Connection conectar() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, CLAVE);
    }
}
