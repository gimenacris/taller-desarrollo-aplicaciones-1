/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import vista.CMenu;

public class CEjecutar {

    public static void main(String[] args) {
        CMenu menu = new CMenu();
        menu.setVisible(true);
    }
}
