/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Carnet;
import vista.CMenu;
import vista.CCarnet;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.util.ArrayList;

public class MenuControlador implements ActionListener, MouseListener, KeyListener {

    private final CMenu vista;
    private static final ArrayList<Carnet> carnets = new ArrayList<>();
    private Carnet carnetSeleccionado = null;

    public MenuControlador(CMenu vista) {
        this.vista = vista;

        this.vista.btnCrear.addActionListener(this);
        this.vista.btnActualizar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
        this.vista.btnSalir.addActionListener(this);

        this.vista.tblDatos.addMouseListener(this);
        this.vista.txtBuscar.addKeyListener(this);

        this.vista.btnActualizar.setEnabled(false);
        this.vista.btnEliminar.setEnabled(false);

        actualizarTabla(carnets);
    }

    private void actualizarTabla(ArrayList<Carnet> lista) {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Código");
        modelo.addColumn("DNI");
        modelo.addColumn("Nombre Completo");
        modelo.addColumn("Facultad");
        modelo.addColumn("Carrera");

        for (Carnet c : lista) {
            modelo.addRow(new Object[]{
                c.getCodigo(),
                c.getDni(),
                c.getNombreCompleto(),
                c.getFacultad(),
                c.getCarrera()
            });
        }

        vista.tblDatos.setModel(modelo);
    }

    private void buscarCarnet() {
        String texto = vista.txtBuscar.getText().toLowerCase();
        ArrayList<Carnet> resultados = new ArrayList<>();

        for (Carnet c : carnets) {
            if (c.getDni().toLowerCase().contains(texto)
                    || c.getCodigo().toLowerCase().contains(texto)
                    || c.getNombreCompleto().toLowerCase().contains(texto)) {
                resultados.add(c);
            }
        }

        actualizarTabla(resultados);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.btnCrear) {
            crear();
        } else if (source == vista.btnActualizar) {
            actualizar();
        } else if (source == vista.btnEliminar) {
            eliminar();
        } else if (source == vista.btnSalir) {
            salir();
        }
    }

    private void crear() {
        CCarnet dialogo = new CCarnet(vista, true, "crear", this);
        dialogo.setVisible(true);
        actualizarTabla(carnets);
        limpiarSeleccion();
    }

    private void actualizar() {
        if (carnetSeleccionado != null) {
            CCarnet dialogo = new CCarnet(vista, true, "actualizar", this);
            dialogo.setVisible(true);
            actualizarTabla(carnets);
            limpiarSeleccion();
        } else {
            JOptionPane.showMessageDialog(vista, "Seleccione un carnet primero.");
        }
    }

    private void eliminar() {
        if (carnetSeleccionado != null) {
            int confirm = JOptionPane.showConfirmDialog(vista, "¿Seguro de eliminar este carnet?", "Confirmar", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                carnets.remove(carnetSeleccionado);
                actualizarTabla(carnets);
                carnetSeleccionado = null;
                limpiarSeleccion();
            }
        } else {
            JOptionPane.showMessageDialog(vista, "Seleccione un carnet primero.");
        }
    }

    private void salir() {
        int respuesta = JOptionPane.showOptionDialog(vista, "¿Estás seguro de salir?", "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, new Object[]{"Sí", "No"}, "No");
        if (respuesta == 0) {
            System.exit(0);
        }
        vista.txtBuscar.requestFocus();
    }

    private void limpiarSeleccion() {
        carnetSeleccionado = null;
        vista.btnActualizar.setEnabled(false);
        vista.btnEliminar.setEnabled(false);
        vista.tblDatos.clearSelection();
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        int fila = vista.tblDatos.getSelectedRow();
        if (fila >= 0) {
            String dniSeleccionado = (String) vista.tblDatos.getValueAt(fila, 1); // columna 1 = DNI
            for (Carnet c : carnets) {
                if (c.getDni().equals(dniSeleccionado)) {
                    carnetSeleccionado = c;
                    break;
                }
            }
            vista.btnActualizar.setEnabled(true);
            vista.btnEliminar.setEnabled(true);
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getSource() == vista.txtBuscar) {
            buscarCarnet();
        }
    }

    // Métodos vacíos que se deben implementar
    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    // Métodos para acceder desde el CarnetControlador
    public void agregarCarnet(Carnet c) {
        carnets.add(c);
    }

    public Carnet getCarnetSeleccionado() {
        return carnetSeleccionado;
    }
}
