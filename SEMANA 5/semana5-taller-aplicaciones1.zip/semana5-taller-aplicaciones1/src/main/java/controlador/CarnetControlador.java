/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Carnet;
import vista.CCarnet;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CarnetControlador implements ActionListener {

    private final CCarnet vista;
    private final String tipo;
    private final MenuControlador menuControlador;

    public CarnetControlador(CCarnet vista, String tipo, MenuControlador menuControlador) {
        this.vista = vista;
        this.tipo = tipo;
        this.menuControlador = menuControlador;

        this.vista.btnCrear.addActionListener(this);
        this.vista.btnVolver.addActionListener(this);

        if (tipo.equalsIgnoreCase("actualizar")) {
            cargarDatos();
        }
    }

    private void cargarDatos() {
        Carnet carnet = menuControlador.getCarnetSeleccionado();
        if (carnet != null) {
            vista.txtCodigo.setText(carnet.getCodigo());
            vista.txtDni.setText(carnet.getDni());
            vista.txtNombre.setText(carnet.getNombreCompleto());
            vista.cmbFacultad.setSelectedItem(carnet.getFacultad());

            vista.actualizarCarreras(); // 💬 Ahora llamas a la vista para actualizar carreras.

            vista.cmbCarrera.setSelectedItem(carnet.getCarrera());

            vista.txtCodigo.setEditable(false);
            vista.txtDni.setEditable(false);
        }
    }

    private boolean validarCampos() {
        if (vista.txtCodigo.getText().trim().isEmpty()
                || vista.txtDni.getText().trim().isEmpty()
                || vista.txtNombre.getText().trim().isEmpty()
                || vista.cmbFacultad.getSelectedIndex() == -1
                || vista.cmbCarrera.getSelectedIndex() == -1) {
            JOptionPane.showMessageDialog(vista, "Todos los campos deben estar completos.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    private void crearCarnet() {
        Carnet nuevo = new Carnet(
                vista.txtCodigo.getText(),
                vista.txtDni.getText(),
                vista.txtNombre.getText(),
                (String) vista.cmbFacultad.getSelectedItem(),
                (String) vista.cmbCarrera.getSelectedItem()
        );
        menuControlador.agregarCarnet(nuevo);
        JOptionPane.showMessageDialog(vista, "Carnet creado exitosamente.");
        vista.dispose();
    }

    private void actualizarCarnet() {
        Carnet carnet = menuControlador.getCarnetSeleccionado();
        if (carnet != null) {
            carnet.actualizarDatos(
                    vista.txtNombre.getText(),
                    (String) vista.cmbFacultad.getSelectedItem(),
                    (String) vista.cmbCarrera.getSelectedItem()
            );
            JOptionPane.showMessageDialog(vista, "Carnet actualizado exitosamente.");
            vista.dispose();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.btnVolver) {
            vista.dispose();
        } else if (source == vista.btnCrear) {
            if (validarCampos()) {
                if (tipo.equalsIgnoreCase("crear")) {
                    crearCarnet();
                } else if (tipo.equalsIgnoreCase("actualizar")) {
                    actualizarCarnet();
                }
            }
        }
    }
}
